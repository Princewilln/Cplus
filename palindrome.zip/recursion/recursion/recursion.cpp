// recursion.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
using namespace std;

// Recursive function to check if a string is a palindrome
bool isPalindrome(const string& str, int left, int right) {
    // Base case: if left index is greater than or equal to right index
    if (left >= right) {
        return true;
    }
    // Check if characters at left and right are the same
    if (str[left] != str[right]) {
        return false;
    }
    // Recursive case: move towards the middle
    return isPalindrome(str, left + 1, right - 1);
}

int main()
{
    string word1 = "radar"; // Palindromic word
    string word2 = "hello"; // Non-palindromic word

    // Test palindromic word
    if (isPalindrome(word1, 0, word1.length() - 1)) {
        cout << word1 << " is a palindrome." << endl;
    }
    else {
        cout << word1 << " is not a palindrome." << endl;
    }

    // Test non-palindromic word
    if (isPalindrome(word2, 0, word2.length() - 1)) {
        cout << word2 << " is a palindrome." << endl;
    }
    else {
        cout << word2 << " is not a palindrome." << endl;
    }

	return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
