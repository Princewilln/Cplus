#include "recursiveBinary.h"
#include <iostream>
using namespace std;

int main() {
    const int SIZE = 10;
    arrayListType<int> intList(SIZE); // Create a list with a maximum size of 10
    int num;

    // Input 10 integers
    cout << "Enter 10 integers in sorted order:\n";
    for (int i = 0; i < SIZE; i++) {
        cin >> num;
        intList.insertEnd(num); // Insert each integer at the end of the list
    }

    // Display the list
    cout << "The list of integers is: ";
    intList.print();

    // Search for a specified item
    cout << "Enter an integer to search for: ";
    cin >> num;

    int index = intList.binarySearch(num); // Perform binary search

    if (index != -1) {
        cout << "Integer " << num << " found at index: " << index << endl;
    }
    else {
        cout << "Integer " << num << " not found in the list." << endl;
    }

    return 0;
}
