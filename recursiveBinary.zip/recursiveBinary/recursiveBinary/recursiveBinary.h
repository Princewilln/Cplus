#include <iostream>
#include <cassert>
using namespace std;

#ifndef H_arrayListType
#define H_arrayListType

template <class elemType>
class arrayListType {
public:
    const arrayListType<elemType>& operator=(const arrayListType<elemType>&);
    bool isEmpty() const;
    bool isFull() const;
    int listSize() const;
    int maxListSize() const;
    void print() const;
    bool isItemAtEqual(int location, const elemType& item) const;
    void insertAt(int location, const elemType& insertItem);
    void insertEnd(const elemType& insertItem);
    void removeAt(int location);
    void retrieveAt(int location, elemType& retItem) const;
    void replaceAt(int location, const elemType& repItem);
    void clearList();
    int seqSearch(const elemType& item) const;
    void insert(const elemType& insertItem);
    void remove(const elemType& removeItem);
    int binarySearch(const elemType& item) const; // Declaration for binary search
    int recursiveBinarySearch(int left, int right, const elemType& item) const; // Declaration for recursive binary search

    arrayListType(int size = 100);
    arrayListType(const arrayListType<elemType>& otherList);
    ~arrayListType();

protected:
    elemType* list; // Array to hold the list elements
    int length; // To store the length of the list
    int maxSize; // To store the maximum size of the list
};

// Member function definitions
template <class elemType>
bool arrayListType<elemType>::isEmpty() const {
    return (length == 0);
}

template <class elemType>
bool arrayListType<elemType>::isFull() const {
    return (length == maxSize);
}

template <class elemType>
int arrayListType<elemType>::listSize() const {
    return length;
}

template <class elemType>
int arrayListType<elemType>::maxListSize() const {
    return maxSize;
}

template <class elemType>
void arrayListType<elemType>::print() const {
    for (int i = 0; i < length; i++)
        cout << list[i] << " ";
    cout << endl;
}

template <class elemType>
bool arrayListType<elemType>::isItemAtEqual(int location, const elemType& item) const {
    return (list[location] == item);
}

template <class elemType>
void arrayListType<elemType>::insertAt(int location, const elemType& insertItem) {
    if (location < 0 || location >= maxSize)
        cerr << "The position of the item to be inserted is out of range" << endl;
    else if (length >= maxSize) // List is full
        cerr << "Cannot insert in a full list" << endl;
    else {
        for (int i = length; i > location; i--)
            list[i] = list[i - 1]; // Move the elements down
        list[location] = insertItem; // Insert the item at the specified position
        length++; // Increment the length
    }
}

template <class elemType>
void arrayListType<elemType>::insertEnd(const elemType& insertItem) {
    if (length >= maxSize) // The list is full
        cerr << "Cannot insert in a full list" << endl;
    else {
        list[length] = insertItem; // Insert the item at the end
        length++; // Increment the length
    }
}

template <class elemType>
void arrayListType<elemType>::removeAt(int location) {
    if (location < 0 || location >= length)
        cerr << "The location of the item to be removed is out of range" << endl;
    else {
        for (int i = location; i < length - 1; i++)
            list[i] = list[i + 1]; // Move the elements up
        length--;
    }
}

template <class elemType>
void arrayListType<elemType>::retrieveAt(int location, elemType& retItem) const {
    if (location < 0 || location >= length)
        cerr << "The location of the item to be retrieved is out of range." << endl;
    else
        retItem = list[location];
}

template <class elemType>
void arrayListType<elemType>::replaceAt(int location, const elemType& repItem) {
    if (location < 0 || location >= length)
        cerr << "The location of the item to be replaced is out of range." << endl;
    else
        list[location] = repItem;
}

template <class elemType>
void arrayListType<elemType>::clearList() {
    length = 0;
}

template <class elemType>
int arrayListType<elemType>::seqSearch(const elemType& item) const {
    int loc;
    bool found = false;
    for (loc = 0; loc < length; loc++)
        if (list[loc] == item) {
            found = true;
            break;
        }
    if (found)
        return loc;
    else
        return -1;
}

template <class elemType>
void arrayListType<elemType>::insert(const elemType& insertItem) {
    int loc;
    if (length == 0) // List is empty
        list[length++] = insertItem; // Insert the item and increment the length
    else if (length == maxSize)
        cerr << "Cannot insert in a full list." << endl;
    else {
        loc = seqSearch(insertItem);
        if (loc == -1) // The item to be inserted does not exist in the list
            list[length++] = insertItem;
        else
            cerr << "The item to be inserted is already in the list. No duplicates are allowed." << endl;
    }
}

template <class elemType>
void arrayListType<elemType>::remove(const elemType& removeItem) {
    int loc;
    if (length == 0)
        cerr << "Cannot delete from an empty list." << endl;
    else {
        loc = seqSearch(removeItem);
        if (loc != -1) // The item to be removed exists in the list
            removeAt(loc);
        else
            cout << "The item to be deleted is not in the list." << endl;
    }
}

template <class elemType>
arrayListType<elemType>::arrayListType(int size) {
    if (size < 0) {
        cerr << "The array size must be positive. Creating an array of size 100." << endl;
        maxSize = 100;
    }
    else
        maxSize = size;
    length = 0;
    list = new elemType[maxSize];
}

template <class elemType>
arrayListType<elemType>::~arrayListType() {
    delete[] list;
}

template <class elemType>
arrayListType<elemType>::arrayListType(const arrayListType<elemType>& otherList) {
    maxSize = otherList.maxSize;
    length = otherList.length;
    list = new elemType[maxSize]; // Create the array
    assert(list != NULL); // Terminate if unable to allocate memory space
    for (int j = 0; j < length; j++) // Copy otherList
        list[j] = otherList.list[j];
}

template <class elemType>
const arrayListType<elemType>& arrayListType<elemType>::operator=(const arrayListType<elemType>& otherList) {
    if (this != &otherList) { // Avoid self-assignment
        delete[] list;
        maxSize = otherList.maxSize;
        length = otherList.length;
        list = new elemType[maxSize]; // Create the array
        assert(list != NULL); // If unable to allocate memory space, terminate the program
        for (int i = 0; i < length; i++)
            list[i] = otherList.list[i];
    }
    return *this;
}

// Recursive binary search algorithm
template <class elemType>
int arrayListType<elemType>::recursiveBinarySearch(int left, int right, const elemType& item) const {
    if (left > right) {
        return -1; // Item not found
    }

    int mid = left + (right - left) / 2; // Calculate mid-point

    if (list[mid] == item) {
        return mid; // Item found
    }
    else if (list[mid] > item) {
        return recursiveBinarySearch(left, mid - 1, item); // Search in the left half
    }
    else {
        return recursiveBinarySearch(mid + 1, right, item); // Search in the right half
    }
}

template <class elemType>
int arrayListType<elemType>::binarySearch(const elemType& item) const {
    return recursiveBinarySearch(0, length - 1, item); // Start binary search
}

#endif
