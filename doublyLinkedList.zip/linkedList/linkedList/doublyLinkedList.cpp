#include "doublyLinkedList.h" // Include the doubly linked list header
#include <iostream>
using namespace std;

int main() {
    doublyLinkedList<int> myList; // Create an instance of the doubly linked list
    int num;

    // Ask the user to enter a list of positive integers in ascending order
    cout << "Enter a list of positive integers in ascending order (end with -999): " << endl;
    while (true) {
        cin >> num;
        if (num == -999) {
            break; // End the input when -999 is entered
        }
        if (num > 0) {
            myList.insert(num); // Insert positive integers into the list
        }
        else {
            cout << "Please enter only positive integers." << endl;
        }
    }

    // Print the positive integers in ascending order
    cout << "\nPositive integers in ascending order: ";
    myList.print();

    // Print the positive integers in descending order
    cout << "\nPositive integers in descending order: ";
    myList.reversePrint();

    // Ask the user to enter an item to be deleted
    cout << "\nEnter an item to be deleted: ";
    cin >> num;
    myList.deleteNode(num); // Delete the item

    // Print the list after deleting the item
    cout << "List after deletion: ";
    myList.print();

    // Ask the user to enter an item to be searched
    cout << "\nEnter an item to search: ";
    cin >> num;
    if (myList.search(num)) {
        cout << num << " was found in the list." << endl;
    }
    else {
        cout << num << " was not found in the list." << endl;
    }

    return 0;
}
